@extends('layouts.master')
@section('title')
Add New FAQ
@endsection

@section('content')

<script>
    $(document).ready(function(){

        const accessToken = "{{ Auth::user()->createToken('SastaTareenAdmin Personal Access Client')->accessToken }}";

        var add_new_faq_api="{{ url('api/faq_insert')}}";


        const form = document.getElementById("add_faq_by_admin");
        form.addEventListener("submit", addFAQbyAdmin);
        function addFAQbyAdmin(event) {
            // log.textContent = `Form Submitted! Timestamp: ${event.timeStamp}`;
            event.preventDefault();
            const formData = new FormData(form);
            const formObject = {};

            formData.forEach((value, key)=>{
                // console.log(value);
                formObject[key]=value;
            });
            
            $.ajax({
                url:add_new_faq_api,
                type: "POST",
                headers: {
                    "Authorization": "Bearer "+accessToken,
                    "Accept": "application/json"
                },
                data:formObject,
                success:function(response)
                {
                    
                    
                    alert(response.response.msg);
                    window.location.href = "/faqs";
            

                
                },
                error: function(xhr, status, error) {
                if (xhr.responseJSON && xhr.responseJSON.response && xhr.responseJSON.response.msg) {
                    alert("Error: " + xhr.responseJSON.response.msg);
                } else {
                    alert("AJAX Error: " + error);
                }
                }

            })
        }

    });
</script>

<div>
    <div class="parallel-heading-div">
        <p class="dashboard-main-heading">
            FAQs > <span class="breadcrumb-small-text">Add New FAQ</span>
        </p>
    </div>
    <div class="add-form-div">
        <form id = "add_faq_by_admin" method="post">
            <div class="form-innner-div">
                <div class="column-div">
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Question</label>
                        </div>
                        <div>
                            <input type="textarea" name="question" placeholder="Question" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Answer</label>
                        </div>
                        <div>
                            <input type="textarea" name="answer" placeholder="Answer" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <!-- <div class="label-div">
                            <label>Submit</label>
                        </div> -->
                        <button type="submit" id="add-faq-by-admin" class="btn btn-success">
                            Submit
                        </button>
                    </div>
                    
                    
                </div>
                <!-- <div class="column-div">
                    
                    
                    
                </div> -->
            </div>
        </form>
    </div>
</div>
@endsection
