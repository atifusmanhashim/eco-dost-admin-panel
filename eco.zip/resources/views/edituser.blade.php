@extends('layouts.master')
@section('title')
Edit User
@endsection

@section('content')
<script>
$(document).ready(function() {

    var update_user_api = "{{ url('api/update_user_details')}}";

    const accessToken =
        "{{ Auth::user()->createToken('SastaTareenAdmin Personal Access Client')->accessToken }}";

    const sel_user_id = "{{ $sel_user_id}}";

    // console.log(sel_user_id);

    const form = document.getElementById("update_user_by_admin");
    form.addEventListener("submit", updateUserbyAdmin);

    function updateUserbyAdmin(event) {
        // log.textContent = `Form Submitted! Timestamp: ${event.timeStamp}`;
        event.preventDefault();
        const formData = new FormData(form);
        const formObject = {};

        formData.forEach((value, key) => {
            // console.log(value);
            formObject[key] = value;
        });
        const userLocationDropdown = document.querySelector(".user_location_id_update");
        var LselectedOption = userLocationDropdown.options[userLocationDropdown.selectedIndex];
        const locationId = LselectedOption.getAttribute("data-id");

        formObject["location_id"] = locationId;

        formObject["user_id"] = sel_user_id;

        const userRoleDropdown = document.querySelector(".user_role_id_update");
        var selectedOption = userRoleDropdown.options[userRoleDropdown.selectedIndex];
        const roleId = selectedOption.getAttribute("data-id");

        formObject["role_id"] = roleId;
        // console.log(formObject);

        $.ajax({
            url: update_user_api,
            type: "POST",
            headers: {
                "Authorization": "Bearer " + accessToken,
                "Accept": "application/json"
            },
            data: formObject,
            success: function(response) {


                alert(response.response.msg);
                window.location.reload();



            },
            error: function(xhr, status, error) {
                if (xhr.responseJSON && xhr.responseJSON.response && xhr.responseJSON.response
                    .msg) {
                    alert("Error: " + xhr.responseJSON.response.msg);
                } else {
                    alert("AJAX Error: " + error);
                }
            }

        })
    }
});
</script>
<div>
    <div class="parallel-heading-div">
        <p class="dashboard-main-heading">
            All Users > <span class="breadcrumb-small-text">Edit User </span>
        </p>
    </div>
    <div class="add-form-div">
        <form id="update_user_by_admin" method="post">
            <div class="form-innner-div">
                <div class="column-div">
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Name</label>
                        </div>
                        <div>
                            <input type="text" value="{{ $user_data->name }}" name="name" placeholder="Name" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Password</label>
                        </div>
                        <div>
                            <input type="text" name="password" placeholder="Password" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Phone No.</label>
                        </div>
                        <div>
                            <input type="text" value="{{ $user_data->contact_no }}" name="contact_no"
                                placeholder="Phone Number e.g. 03001231231" />
                        </div>
                    </div>

                </div>
                <div class="column-div">
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Email</label>
                        </div>
                        <div>
                            <input type="email" value="{{ $user_data->email }}" name="email" placeholder="Email" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Role</label>
                        </div>
                        <div>
                            <select name="role_id" class="user_role_id_update">
                                @foreach($available_roles as $itm)
                                <option name="role_id" data-id="{{ $itm['role_id'] }}"
                                    @if($itm['role_id']===$user_data->role_id) selected @endif>{{ $itm['role_name'] }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Location</label>
                        </div>
                        <select class="user_location_id_update">
                            @foreach($available_locations as $itm)
                            <option name="location_id" data-id="{{ $itm['location_id'] }}"
                                @if($itm['location_id']===$user_data->location_id) selected @endif
                                >{{ $itm['location_name'] }}</option>
                            @endforeach
                        </select>
                    </div>

                </div>

            </div>
            <div class="input-outer-div">
                <!-- <div class="label-div">
                            <label>Submit</label>
                        </div> -->
                <button id="update-user-by-admin" class="btn btn-success">
                    Submit
                </button>
            </div>
        </form>
    </div>
</div>
@endsection