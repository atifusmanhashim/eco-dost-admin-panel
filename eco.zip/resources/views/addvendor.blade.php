@extends('layouts.master')
@section('title')
Add New Dealer
@endsection

@section('content')

<script>
    $(document).ready(function(){

        const accessToken = "{{ Auth::user()->createToken('SastaTareenAdmin Personal Access Client')->accessToken }}";

        var add_new_dealer_api="{{ url('api/create_vendor')}}";

        document.getElementById("add-dealer-by-admin").addEventListener("click", addDealerbyAdmin);
        function addDealerbyAdmin()
        {
            // console.log("saad");
            // alert("saad");
            var sel_dealer_name=document.getElementById("dealer-name-text").value;
            var sel_dealer_company_name = document.getElementById("dealer-company-name-text").value;

            var sel_dealer_address = document.getElementById("dealer-address-text").value;

            var sel_dealer_phone = document.getElementById("dealer-phone-text").value;
            var sel_dealer_password = document.getElementById("dealer-password-text").value;
            var sel_vendor_id= document.getElementById("vendor_type_id").value;
            // console.log(sel_dealer_name);
            // console.log(sel_dealer_company_name);
            // console.log(sel_dealer_address);
            // console.log(sel_dealer_phone);
            // console.log(sel_dealer_password);


            var form_data={
                'name':sel_dealer_name,
                'company_name':sel_dealer_company_name,
                'address':sel_dealer_address,
                'phone_no':sel_dealer_phone,
                'password':sel_dealer_password,
                'vendor_type_id':sel_vendor_id
            };
            $.ajax({
                url:add_new_dealer_api,
                type: "POST",
                headers: {
                    "Authorization": "Bearer "+accessToken,
                    "Accept": "application/json"
                },
                data:form_data,
                success:function(response)
                {


                    alert(response.response.msg);
                    window.location.href = "/vendors";



                },
                error: function(xhr, status, error) {
                if (xhr.responseJSON && xhr.responseJSON.response && xhr.responseJSON.response.msg) {
                    alert("Error: " + xhr.responseJSON.response.msg);
                } else {
                    alert("AJAX Error: " + error);
                }
                }

            })

        }

    });
</script>

<div>
    <div class="parallel-heading-div">
        <p class="dashboard-main-heading">
           Dealer > <span class="breadcrumb-small-text">Add New Dealer</span>
        </p>
    </div>


    <div class="add-form-div">
        <!-- <form> -->
            <div class="row">
                <div class="form-group col">
                    <label for="dealer-name-text">Dealer Name</label>
                    <input type="text" class="form-control" id="dealer-name-text" placeholder="Full Name" />
                </div>
                <div class="form-group col">
                    <label>Company Name</label>
                    <input type="text" class="form-control" id="dealer-company-name-text" placeholder="Company Name" />
                </div>
            </div>
            <hr>
            <div class="row mx-auto">
                <div class="form-group col">
                    <label>Address</label>
                    <input type="text" class="form-control" id="dealer-address-text" placeholder="Address" />
                </div>
                <div class="form-group col">
                    <label>Type</label>
                    <select name="vendor_type_id" class="form-control form-select" id="vendor_type_id"  class="vendor_type_id">
                        @foreach($vendor_type as $itm)
                            <option value="{{ $itm->vendor_type_id }}">{{ $itm->vendor_type_name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <hr>
            <div class="row mx-auto">
                <div class="form-group col">
                    <label>Phone No.</label>
                    <input type="tel" class="form-control" id="dealer-phone-text" placeholder="Phone Number e.g. 03001231231" />
                </div>
                <div class="form-group col">
                    <label>Password</label>
                    <input type="text" class="form-control" id="dealer-password-text" placeholder="Enter Password" />
                </div>
            </div>
            <hr>
            <button id="add-dealer-by-admin" name="add-dealer-by-admin" class="btn btn-success w-100">
                Save
            </button>

        <!-- </form> -->
    </div>
</div>
@endsection
