@extends('layouts.master')
@section('title')
Add New FAQ
@endsection

@section('content')

<script>
    $(document).ready(function(){

        const accessToken = "{{ Auth::user()->createToken('SastaTareenAdmin Personal Access Client')->accessToken }}";

        var update_faq_api="{{ url('api/update_faq')}}";

        const sel_faq_id="{{ $sel_faq_id}}";


        document.getElementById("update-faq-by-admin").addEventListener("click", updateFAQbyAdmin);
        function updateFAQbyAdmin()
        {
            // console.log("saad");
            // alert("saad");
            var sel_faq_question=document.getElementById("faq-question-text").value;
            var sel_faq_answer = document.getElementById("faq-answer-text").value;

            
            // console.log(sel_dealer_name);
            // console.log(sel_dealer_company_name);
            // console.log(sel_dealer_address);
            // console.log(sel_dealer_phone);
            // console.log(sel_dealer_password);


            var form_data={
                'id':sel_faq_id,
                'question':sel_faq_question,
                'answer':sel_faq_answer,
            };
            $.ajax({
                url:update_faq_api,
                type: "POST",
                headers: {
                    "Authorization": "Bearer "+accessToken,
                    "Accept": "application/json"
                },
                data:form_data,
                success:function(response)
                {


                    alert(response.response.msg);
                    // window.location.href = "/vendors";
                    window.location.reload();



                },
                error: function(xhr, status, error) {
                if (xhr.responseJSON && xhr.responseJSON.response && xhr.responseJSON.response.msg) {
                    alert("Error: " + xhr.responseJSON.response.msg);
                } else {
                    alert("AJAX Error: " + error);
                }
                }

            })

        }

    });
</script>

<div>
    <div class="parallel-heading-div">
        <p class="dashboard-main-heading">
            FAQs > <span class="breadcrumb-small-text"> Edit FAQ </span>
        </p>
    </div>
    <div class="add-form-div">
        <form id = "add_faq_by_admin" method="post">
            <div class="form-innner-div">
                <div class="column-div">
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Question</label>
                        </div>
                        <div>
                            <input type="textarea" value="{{ $faq->question }}" id="faq-question-text" name="question" placeholder="Question" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <div class="label-div">
                            <label>Answer</label>
                        </div>
                        <div>
                            <input type="textarea" value="{{ $faq->answer }}" id="faq-answer-text" name="answer" placeholder="Answer" />
                        </div>
                    </div>
                    <div class="input-outer-div">
                        <!-- <div class="label-div">
                            <label>Submit</label>
                        </div> -->
                        <button type="submit" id="update-faq-by-admin" class="btn btn-success">
                            Submit
                        </button>
                    </div>
                    
                    
                </div>
                <!-- <div class="column-div">
                    
                    
                    
                </div> -->
            </div>
        </form>
    </div>
</div>
@endsection
