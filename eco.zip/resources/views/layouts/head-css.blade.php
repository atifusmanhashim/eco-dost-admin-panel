@yield('css')

<!-- preloader css -->
<link rel="stylesheet" href="{{ URL::asset('css/layout.css') }}" type="text/css" />


