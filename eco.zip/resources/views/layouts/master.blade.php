<!DOCTYPE html>
<html lang="en">

<head>
    <title> Welcome {{ request()->session()->get('user_name') }} | ECO DOST Admin Panel - @yield('title') </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="{{URL::asset('css/layout.css')}}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
</head>

<body>
    <div class="layout-wrapper">
        <div class="sidebar">
            <div class="logo-div">
                <img src="{{url::asset('images/ecodost-logo.svg')}}" />

            </div>

            <a href="{{url('/dashboard')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/dashboard-icon.svg')}}" />
                        </div>
                        <div class="sidebar-link-text">
                            Dashboard
                        </div>
                    </div>
                </div>
            </a>

            <a href="{{url('/complaints')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/Complaint.svg')}}" />

                        </div>
                        <div class="sidebar-link-text">
                            Complaints
                        </div>
                    </div>
                </div>
            </a>
            <a href="{{url('/inventory')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/inventory.svg')}}" />
                        </div>
                        <div class="sidebar-link-text">
                            Inventory
                        </div>
                    </div>
                </div>
            </a>

            <a href="{{url('/users')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/user-icon.svg')}}" />

                        </div>
                        <div class="sidebar-link-text">
                            Users

                        </div>
                    </div>
                </div>
            </a>
            <a href="{{url('/vendors')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/vendor-icon.svg')}}" />

                        </div>
                        <div class="sidebar-link-text">
                            Dealers
                        </div>
                    </div>
                </div>
            </a>
            <a href="{{url('/faqs')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/FAQs.svg')}}" />

                        </div>
                        <div class="sidebar-link-text">
                            FAQs
                        </div>
                    </div>
                </div>
            </a>
            <a href="{{url('/logout')}}">
                <div class="sidebar-links-outer-div">
                    <div class="sidebar-link">
                        <div>
                            <img src="{{url::asset('images/logout.svg')}}" />
                        </div>
                        <div class="sidebar-link-text">
                            Logout
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="right-div">
            <div class="header-div">
                <div class="header-inner-div">
                    <div class="dropdown">
                        <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <img src="{{url::asset('images/Doorbell.svg')}}" />

                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                        </li>
                    </div>
                    <div class="dropdown">
                        <a class="dropdown-toggle dropdown-name" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <div> <img src="{{url::asset('images/default-user-img.jpg')}}"
                                    style="border-radius: 50%;" /></div>
                            <div> {{ request()->session()->get('user_name') }} </div>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                        </li>
                    </div>
                </div>
            </div>
            <div class="content-div">
                @yield('content')
            </div>
        </div>
    </div>

    <!--  Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

    <script>
    $(document).ready(function() {
        $('#inventory-table').DataTable({
            "aLengthMenu": [
                [5, 10, 25, -1],
                [5, 10, 25, "All"]
            ],
            "iDisplayLength": 5
        });
    });
    </script>


</body>


</html>