@extends('layouts.master')
@section('title')
All Users
@endsection

@section('content')

<script>
    const accessToken = "{{ Auth::user()->createToken('SastaTareenAdmin Personal Access Client')->accessToken }}";

    var delete_user_api="{{ url('api/delete-user')}}";

    function deleteAdminUser(event) {
        if (confirm("Are you sure you want to delete this user?") == true) {
            const userId = event.currentTarget.getAttribute("data-id");
            // Now you can use the dataId variable for further processing or deletion
            // console.log("Data ID:", userId);
            // Perform your deletion logic here using the dataId variable
            const formObject = {
                user_id: userId // Add any other data you want to send to the server
            };
            $.ajax({
                    url:delete_user_api,
                    type: "POST",
                    headers: {
                        "Authorization": "Bearer "+accessToken,
                        "Accept": "application/json"
                    },
                    data:formObject,
                    success:function(response)
                    {
                        
                        
                        alert(response.response.msg);
                        window.location.href = "/users";
                

                    
                    },
                    error: function(xhr, status, error) {
                    if (xhr.responseJSON && xhr.responseJSON.response && xhr.responseJSON.response.msg) {
                        alert("Error: " + xhr.responseJSON.response.msg);
                    } else {
                        alert("AJAX Error: " + error);
                    }
                    }

                })

        } else {
            console.log("You canceled!");
            // Handle the cancel action if needed
        }
    }
    function searchTable() {
        // Declare variables
        var input, filter, table, tr, td, i, j, txtValue;
        input = document.getElementById("searchBox");
        filter = input.value.toUpperCase();
        table = document.getElementById("table_data");
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows (except the header row), and hide those who don't match the search query
        for (i = 1; i < tr.length; i++) { // Start from index 1 to skip the header row (th)
            var foundMatch = false;
            // Loop through all table columns (td elements) for each row (tr element)
            for (j = 0; j < tr[i].getElementsByTagName("td").length; j++) {
                td = tr[i].getElementsByTagName("td")[j];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        foundMatch = true;
                        break; // If a match is found in any column, no need to check the rest
                    }
                }
            }
            // Show/hide the row based on whether a match was found
            if (foundMatch) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }

    $(document).ready(function(){
        $('.edit_user_btn').click(function(){
            var sel_user_id=$(this).attr('data-id');
            // console.log(sel_user_id);
            window.location.href="{{url('/edituser')}}/"+sel_user_id;
        });


    });
</script>


<div>
    <div class="parallel-heading-div">
        <p class="dashboard-main-heading">
        Admin Users
        </p>
        <div class="search-input-div" >
            <input type="search" placeholder="search" id="searchBox" onkeyup="searchTable()"/>
        </div>
        <div class="tabs-btn-div">

            <button onclick="window.location.href='{{url('/adduser')}}'">+ Add New User</button>
        </div>
    </div>
    <div class="table-responsive table-div" style="max-width: 1400px;">
        <table class="table" id="table_data">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Phone No.</th>
                    <th scope="col">Date of Joining</th>
                    <th scope="col">Role</th>
                    <th scope="col">Location</th>
                    <th scope="col">Login Status</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $count = 1; ?>
                @foreach($user_lst_recs as $itm)

                <tr>
                    <td>{{ $count }}</td>
                    <td>{{ $itm['user_id'] }}</td>
                    <td>{{ $itm['user_name'] }}</td>
                    <td>{{ $itm['contact_no'] }}</td>
                    <td>{{ $itm['created_at'] }}</td>
                    <td>{{ $itm['role_name'] }}</td>
                    <td>{{ $itm['location_name'] }}</td>
                    <td>{{ $itm['account_status'] }}</td>
                    <td>{{ $itm['user_status'] }}</td>
                    <td>
                        <div class="two-btn-div">
                            <button class="edit_user_btn" data-id= "{{ $itm['user_id'] }}" class="edit-btn"> <img class="edit-icon"
                                    src="{{url('images/edit-icon.svg')}}" /></button>
                            <button onclick="deleteAdminUser(event)" data-id="{{ $itm['user_id'] }}" class="edit-btn"> <img class="delete-icon"
                                src="{{url('images/delete-icon.svg')}}" /></button>
                        </div>
                    </td>
                </tr>
                <?php $count++; ?>
                @endforeach

            </tbody>
        </table>
    </div>
</div>
@endsection








